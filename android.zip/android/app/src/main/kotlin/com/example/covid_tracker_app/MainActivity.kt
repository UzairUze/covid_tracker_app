package com.example.covid_tracker_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
